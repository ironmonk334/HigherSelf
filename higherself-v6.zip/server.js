require('dotenv').config();
const express = require('express');
const multer = require('multer');
const path = require('path');
const os = require('os');
const fs = require('fs');
const FormData = require('form-data');
const fetch = require('node-fetch');
const Anthropic = require('@anthropic-ai/sdk');

const app = express();
const PORT = 3000;

const upload = multer({ dest: path.join(__dirname, 'uploads'), limits: { fileSize: 25 * 1024 * 1024 } });
app.use(express.json({ limit: '25mb' }));
app.use(express.static(path.join(__dirname, 'public')));

if (!fs.existsSync(path.join(__dirname, 'uploads'))) fs.mkdirSync(path.join(__dirname, 'uploads'));

let anthropic = null;
if (process.env.ANTHROPIC_API_KEY) {
  anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
}

const sessions = {
  voiceId: null, avatarUrl: null, goals: [], language: 'en', conversationHistory: []
};

const LANGUAGES = {
  en: { name: 'English', speechCode: 'en', systemLabel: 'English' },
  fr: { name: 'Français', speechCode: 'fr', systemLabel: 'French' },
  es: { name: 'Español', speechCode: 'es', systemLabel: 'Spanish' },
};

// SETUP
app.post('/api/setup', (req, res) => {
  sessions.goals = req.body.goals || [];
  sessions.language = req.body.language || 'en';
  sessions.conversationHistory = [];
  res.json({ success: true });
});

// VOICE CLONING — ElevenLabs
app.post('/api/clone-voice', upload.single('audio'), async (req, res) => {
  try {
    console.log('🎙 Cloning voice...');
    if (!process.env.ELEVENLABS_API_KEY) return res.status(500).json({ error: 'ElevenLabs API key not configured' });
    const audioPath = req.file.path;
    const formData = new FormData();
    formData.append('name', 'HigherSelf_' + Date.now());
    formData.append('description', 'HigherSelf voice clone');
    formData.append('files', fs.createReadStream(audioPath), { filename: 'voice.webm', contentType: req.file.mimetype || 'audio/webm' });
    const response = await fetch('https://api.elevenlabs.io/v1/voices/add', {
      method: 'POST', headers: { 'xi-api-key': process.env.ELEVENLABS_API_KEY }, body: formData
    });
    const data = await response.json();
    try { fs.unlinkSync(audioPath); } catch(e) {}
    if (!response.ok) { console.error('ElevenLabs error:', data); return res.status(response.status).json({ error: data.detail?.message || data.detail || JSON.stringify(data) }); }
    sessions.voiceId = data.voice_id;
    console.log('✅ Voice cloned! ID:', data.voice_id);
    res.json({ success: true, voiceId: data.voice_id });
  } catch (err) { console.error('Voice clone error:', err); res.status(500).json({ error: err.message }); }
});

// SPEECH-TO-TEXT — ElevenLabs Scribe
app.post('/api/transcribe', upload.single('audio'), async (req, res) => {
  try {
    if (!process.env.ELEVENLABS_API_KEY) return res.status(500).json({ error: 'ElevenLabs API key not configured' });
    const audioPath = req.file.path;
    const lang = LANGUAGES[sessions.language] || LANGUAGES.en;
    const formData = new FormData();
    formData.append('file', fs.createReadStream(audioPath), { filename: 'speech.webm', contentType: req.file.mimetype || 'audio/webm' });
    formData.append('model_id', 'scribe_v1');
    formData.append('language_code', lang.speechCode);
    const response = await fetch('https://api.elevenlabs.io/v1/speech-to-text', {
      method: 'POST', headers: { 'xi-api-key': process.env.ELEVENLABS_API_KEY }, body: formData
    });
    const data = await response.json();
    try { fs.unlinkSync(audioPath); } catch(e) {}
    if (!response.ok) { console.error('STT error:', data); return res.status(response.status).json({ error: data.detail?.message || data.detail || 'Transcription failed' }); }
    const text = data.text || '';
    console.log('🗣 User said:', text);
    res.json({ success: true, text });
  } catch (err) { console.error('STT error:', err); res.status(500).json({ error: err.message }); }
});

// AVATAR GENERATION — Replicate
app.post('/api/generate-avatar', async (req, res) => {
  try {
    console.log('🎨 Generating avatar...');
    if (!process.env.REPLICATE_API_TOKEN) return res.status(500).json({ error: 'Replicate API token not configured' });
    const { photoDataUrl, goals } = req.body;
    if (!photoDataUrl) return res.status(400).json({ error: 'No photo provided' });
    const goalDescriptions = {
      Fitness: 'extremely fit, athletic, muscular, healthy glowing skin, confident posture',
      Finance: 'wealthy, successful, wearing elegant premium clothing, confident powerful presence',
      Relationships: 'warm, charismatic, glowing with happiness, approachable, radiant smile',
      Mindset: 'serene, wise, focused eyes, calm powerful presence, enlightened',
      Career: 'professional, powerful, executive presence, sharp, commanding respect',
      Wellness: 'radiant health, peaceful, zen-like calm, youthful energy, glowing'
    };
    const goalTraits = (goals || []).map(g => goalDescriptions[g] || '').filter(Boolean).join(', ');
    const prompt = `A photorealistic portrait of the same person but as their ideal future self: ${goalTraits}. Studio lighting, high-end photography, aspirational, confident, the best version of themselves. Maintain exact facial features and identity.`;
    const response = await fetch('https://api.replicate.com/v1/predictions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.REPLICATE_API_TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        version: "435061a1b5a4c1e26740464bf786efdfa9cb3a3ac488595a2de23e143fdb0117",
        input: { image: photoDataUrl, prompt, negative_prompt: "ugly, deformed, distorted face, bad anatomy, blurry, low quality", num_inference_steps: 30, guidance_scale: 7.5, strength: 0.45, seed: Math.floor(Math.random() * 1000000) }
      })
    });
    const prediction = await response.json();
    if (!response.ok) { console.error('Replicate error:', prediction); return res.status(response.status).json({ error: prediction.detail || 'Avatar generation failed' }); }
    let result = prediction; let attempts = 0;
    while (result.status !== 'succeeded' && result.status !== 'failed' && attempts < 60) {
      await new Promise(r => setTimeout(r, 2000));
      const pollRes = await fetch(`https://api.replicate.com/v1/predictions/${result.id}`, { headers: { 'Authorization': `Bearer ${process.env.REPLICATE_API_TOKEN}` } });
      result = await pollRes.json(); attempts++;
      console.log(`  Polling... status: ${result.status} (attempt ${attempts})`);
    }
    if (result.status === 'succeeded') {
      const outputUrl = Array.isArray(result.output) ? result.output[0] : result.output;
      sessions.avatarUrl = outputUrl;
      console.log('✅ Avatar generated!');
      res.json({ success: true, avatarUrl: outputUrl });
    } else { res.status(500).json({ error: 'Avatar generation failed: ' + (result.error || result.status) }); }
  } catch (err) { console.error('Avatar error:', err); res.status(500).json({ error: err.message }); }
});

// COACHING — Claude
app.post('/api/coach/respond', async (req, res) => {
  try {
    if (!anthropic) return res.status(500).json({ error: 'Anthropic API key not configured' });
    const { userMessage, goals, language } = req.body;
    const lang = LANGUAGES[language] || LANGUAGES.en;
    const goalsList = (goals || []).join(', ');
    sessions.conversationHistory.push({ role: 'user', content: userMessage });
    const systemPrompt = `You are the user's "Higher Self" — a future, more accomplished version of themselves who has already achieved their goals. You speak as if you ARE them, from the future.

CRITICAL: You MUST respond entirely in ${lang.systemLabel}. Every word must be in ${lang.systemLabel}.

Your coaching approach combines:
- Cognitive Behavioral Therapy (CBT): Identify and reframe negative thought patterns
- Motivational Interviewing: Draw out the person's own motivation for change
- Neuroplasticity principles: The brain physically rewires through repeated practice
- Habit stacking: Connect new habits to existing routines
- Future-self visualization: You ARE the proof that change is possible

The user's goals are: ${goalsList}

Rules:
- Speak in first person as their future self ("I remember when I was where you are...")
- Be conversational, not preachy — like talking to yourself
- Keep responses to 2-3 sentences maximum. This is a phone call, not a lecture.
- Ask one thoughtful question to keep the conversation going
- Reference their specific goals naturally
- Be honest and direct — you're them, so you know their excuses
- Occasionally reference specific achievements you (future self) have accomplished
- ALWAYS respond in ${lang.systemLabel}`;
    const messages = sessions.conversationHistory.slice(-12).map(m => ({ role: m.role, content: m.content }));
    const response = await anthropic.messages.create({ model: 'claude-sonnet-4-20250514', max_tokens: 250, system: systemPrompt, messages });
    const reply = response.content[0].text;
    sessions.conversationHistory.push({ role: 'assistant', content: reply });
    console.log('🧠 Higher Self:', reply);
    res.json({ success: true, reply });
  } catch (err) { console.error('Coach error:', err); res.status(500).json({ error: err.message }); }
});

// TEXT-TO-SPEECH — ElevenLabs
app.post('/api/speak', async (req, res) => {
  try {
    if (!process.env.ELEVENLABS_API_KEY) return res.status(500).json({ error: 'ElevenLabs API key not configured' });
    const { text } = req.body;
    const voiceId = sessions.voiceId;
    if (!voiceId) return res.status(400).json({ error: 'No cloned voice. Clone your voice first.' });
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: 'POST',
      headers: { 'xi-api-key': process.env.ELEVENLABS_API_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, model_id: 'eleven_multilingual_v2', voice_settings: { stability: 0.5, similarity_boost: 0.85, style: 0.4, use_speaker_boost: true } })
    });
    if (!response.ok) { const e = await response.json().catch(() => ({})); return res.status(response.status).json({ error: e.detail || 'TTS failed' }); }
    res.set({ 'Content-Type': 'audio/mpeg', 'Transfer-Encoding': 'chunked' });
    response.body.pipe(res);
  } catch (err) { console.error('TTS error:', err); res.status(500).json({ error: err.message }); }
});

app.post('/api/reset', (req, res) => {
  sessions.voiceId = null; sessions.avatarUrl = null; sessions.goals = []; sessions.conversationHistory = [];
  res.json({ success: true });
});

function getLocalIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) for (const iface of interfaces[name]) if (iface.family === 'IPv4' && !iface.internal) return iface.address;
  return 'localhost';
}

app.listen(PORT, '0.0.0.0', () => {
  const ip = getLocalIP();
  console.log('');
  console.log('  ✨ HigherSelf v4 is running!');
  console.log('  ─────────────────────────────────');
  console.log(`  On this PC:     http://localhost:${PORT}`);
  console.log(`  On your phone:  http://${ip}:${PORT}`);
  console.log('  ─────────────────────────────────');
  console.log('  API Keys:');
  console.log(`    Claude:     ${anthropic ? '✅ Connected' : '❌ Missing (ANTHROPIC_API_KEY)'}`);
  console.log(`    ElevenLabs: ${process.env.ELEVENLABS_API_KEY ? '✅ Connected' : '❌ Missing'}`);
  console.log(`    Replicate:  ${process.env.REPLICATE_API_TOKEN ? '✅ Connected' : '❌ Missing'}`);
  console.log('  ─────────────────────────────────');
  console.log('  📱 Works on iPhone, Android, and desktop!');
  console.log('');
});
